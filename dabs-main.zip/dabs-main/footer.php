   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Category</p> <hr>
					<ul>
						<li><a href="signin.php">Search for Doctors</a></li>
						<li><a href="signin.php">Contact with Doctors</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contact</p> <hr>
						<p>Abhas,Anushka,Viraj,Onkar <br>
						panushkapawar92@gmail.com<br>
						    onkarkulkarni3107@gmail.com<br>
							ajmodak@mitaoe.ac.in <br>
							 jadhavvr@mitaoe.ac.in<br>
							Cell: 9545778445</p>
							<span style="color: red;font-size: 15px">&copy;<?php echo date('Y'); ?>-All Rights Reserved</span>
					</div>
					<div class="col-md-4 share_img">
					<p>Link With</p> <hr>
						<a href="https://www.linkedin.com/in/anushka-pawar-a07935212/" ><img src="img/linke.jpg" alt="linkedin"></a>
						<a href="https://wa.me/9307939226"><img src="img/wp.jpg" alt="wp"></a>
						<a href="https://twitter.com/abhasmodak"><img src="img/twitter.png" alt="twitter"></a>
						<a href="https://instagram.com/viraaaj_7?igshid=YmMyMTA2M2Y="><img src="img/insta.png" alt="insta"></a>
						
					</div>
				</div>
				
				

			</footer>

		<!-- footer section Ends--> 
