<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="doctors">
        
		                    <h3 class="text-center" style="background-color:#272327;color: #fff;">Doctors of Maharashtra</h3>
                            <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/viraj..jpeg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr. Viraj Jadhav</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        MBBS, BCS (Health), MS (Gynecologist &amp; Obstetrics)Gynecologist &amp; Obstetrics Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                        Chamber: Seba Diagnostics, Charu Babur Mor, satara
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                      Call for Appoinment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone:+918080655597
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/abhas.JPEG" alt="" class="img-responsive" style="width: 220px;height: 220px"> <br>
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">Dr. Abhas Modak</h3>

                                             <!-- Accordian Start -->

                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne1">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne1">
                                                  <div class="panel-body">
                                                        MBBS, MCPS
Senior Consultant
Gynecologist & Obestetrics
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo2">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo2">
                                                  <div class="panel-body">
                                                         Medical College Road (Near Medical College & Al Square Pharmacy), Nagpur
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree3">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree3" aria-expanded="false" aria-controls="collapseThree3">
                                                      Call For Appointment
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree3">
                                                  <div class="panel-body">
                                                     Phone: +919545778445
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>
                                        
                                          <!-- Accordian End -->  
                                            
                                   </div> 
                             </div> <!-- col-md-12 End-->

                            <br><br>


                             <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/Onkar.jpeg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr.Onkar kulkarni</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne11" aria-expanded="true" aria-controls="collapseOne11">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne11" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                       MBBS, MS (Neuro-Surgery)
Expertise: Brain, Nerve & Spine, Neuro-Surgeon
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo22" aria-expanded="false" aria-controls="collapseTwo22">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo22" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                       Jamuna Diagnostic Complex, Near Pune Medical College & Hospital
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree33" aria-expanded="false" aria-controls="collapseThree33">
                                                     Call for Appointment
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree33" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                    Phone: +918177919226
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>


                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/anu.png" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">Dr.Anushka Pawar</h3>

                                             <!-- Accordian Start -->

                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne111" aria-expanded="true" aria-controls="collapseOne111">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne111" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        MBBS (Pune), MD (Medicine)
Medicine Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo222" aria-expanded="false" aria-controls="collapseTwo222">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo222" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                       Seba Diagnostics, Charu Babur Mor, Nashik
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree333" aria-expanded="false" aria-controls="collapseThree333">
                                                      Call For Appointment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree333" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone: +919307781766
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>
                                              
                                            </div>
                                        
                                          <!-- Accordian End -->  
                                            
                                   </div> 
                             </div> <!-- col-md-12 End-->



                              

                            <br><br>


                             




	</div> <!-- Doctors End -->

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
    <!-- footer section Ends--> 
	



		
	</div><!--  containerFluid Ends -->


               <script src="js/jquery-1.11.3.min.js"></script> <!-- this works for collapse -->
                <script src="js/bootstrap.min.js"></script>
	
</body>
</html>