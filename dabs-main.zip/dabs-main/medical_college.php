<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="form-group mc">
		<h2 class="text-center" style="background-color:#272327;color: #fff;">Public Medical College in Maharashtra</h2>

                              <table cellpadding="10" cellspacing="10" class="table table-hover">   

                                  <tr>
                                      <th>No.</th><th>Name</th><th>Acronym</th><th>Established</th><th>Location</th><th>website</td>
                                  </tr>
                                  <tr>
                                      <td>01</td><td>ACPM Medical College</td><td>ACPM</td><td>1946</td><td>Dhule</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>02</td><td>Armed Forces Medical College</td><td>AFM</td><td>1972</td><td>Pune</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>03</td><td>Ashwini Rural Medical College, Hospital & Research Centre</td><td>ARMC</td><td>2006</td><td> Solapur</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>04</td><td>Bharati Vidyapeeth Deemed University Medical College & Hospita</td><td>BVD</td><td>1962</td><td>Sangli</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>05</td><td>Dr. Shankarrao Chavan Govt. Medical College</td><td>SCGMC</td><td>1957</td><td>Nanded</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>06</td><td>Dr. Ulhas Patil Medical College & Hospital</td><td>UPMC</td><td>1958</td><td>Jalgaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>07</td><td>Dr.Vasantrao Pawar Med. Col. Hosp. & Research Centre</td><td>VPMC</td><td>1962</td><td>Nashik</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>08</td><td>Government Medical College</td><td>GMC</td><td>1968</td><td>Aurangabad</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>09</td><td>Government Medical College</td><td>GMC</td><td>1970</td><td>Nagpur</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>10</td><td>Government Medical College </td><td>GMC</td><td>1992</td><td>Akola</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>11</td><td>Government Medical College</td><td>GMC</td><td>1992</td><td>Latur</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>12</td><td>Government Medical College</td><td>GMC</td><td>1992</td><td>Yavatmal</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>13</td><td>Government Medical College</td><td>GMC</td><td>1992</td><td>Gondia</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>14</td><td>Government Medical College</td><td>GMC</td><td>1992</td><td>Amravati</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>15</td><td>Grant Medical College</td><td>GMC</td><td>2008</td><td>Mumbai</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>16</td><td>Indira Gandhi Medical College & Hospita</td><td>IGMC</td><td>2008</td><td>Nagpur</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>17</td><td>Institute of Medical Science and Research, Vidyagiri</td><td>IMSRC</td><td>2008</td><td>Satara</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>18</td><td>Jawaharlal Nehru Medical College, Sawangi (Meghe)</td><td>JMC</td><td>2010</td><td>Wardha</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>19</td><td>KJ Somaiyya Medical College & Research Centre</td><td>SMC</td><td>21951</td><td>Mumbai</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>20</td><td>Krishna Institute of Medical Sciences</td><td>KIMS</td><td>1981</td><td>Karad</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>21</td><td>Lokmanya Tilak Municipal Medical College</td><td>LMTMC</td><td>1989</td><td>Mumbai</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>22</td><td>Maharashtra Institute of Medical Sciences & Research</td><td>MIMSR</td><td>2001</td><td>Latur</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>23</td><td>Maharashtra Institute of Medical Education & Research</td><td>MIMER</td><td>1993</td><td>Pune</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>24</td><td>Mahatma Gandhi Institute of Medical Sciences, Sevagram</td><td>MGIMS</td><td>1996</td><td>Wardha</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>25</td><td>Mahatma Gandhi Missions Medical College</td><td>MGMC</td><td>1986</td><td>Aurangabad</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>26</td><td>Mahatma Gandhi Missions Medical College</td><td>MGMMC</td><td>1999</td><td>Mumbai</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>27</td><td>N. K. P. Salve Institute of Medical Sciences</td><td>NKP</td><td>1990</td><td>Nagpur/td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>28</td><td>Padmashri Dr. Vithalrao Vikhe Patil Foundations Medical College</td><td>VPMC</td><td>2004</td><td>Ahmednagar</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>29</td><td>Rajashree Chatrapati Shahu Maharaj Government Medical College</td><td>RmMC</td><td>1990</td><td>Kolhapu</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>30</td><td>Smt. Kashibai Navale Medical College and Hospital</td><td>MuMC</td><td>2007</td><td>Pune</td><td><a href="#">website</a></td>
                                  </tr>

                                  
                              </table>
	</div>
	

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
		<!-- footer section Ends--> 


	
	</div><!--  containerFluid Ends -->



	<script src="js/bootstrap.min.js"></script>
	
</body>
</html>